package com.example.habit.domain

import com.example.habit.data.model.CheckInOutcome

object Gamification {
    fun xpForDailyCheckIn(outcome: CheckInOutcome): Int = when (outcome) {
        CheckInOutcome.Clean -> 10
        CheckInOutcome.Partial -> 5
        CheckInOutcome.Slip -> 0
    }

    fun xpSevenDayMilestone(): Int = 25
    fun xpHabitBeaten(): Int = 100
    fun xpFirstAiScan(): Int = 20
    fun xpWeeklyRescan(): Int = 10

    fun rankTierLabel(habitsBeaten: Int): String = when {
        habitsBeaten <= 0 -> "Novice"
        habitsBeaten == 1 -> "Aware"
        habitsBeaten == 2 -> "Committed"
        habitsBeaten in 3..4 -> "Disciplined"
        habitsBeaten in 5..6 -> "Elite"
        else -> "Liberated"
    }

    /**
     * PRD: Score = (Habits Beaten × 1000) + (Current Streak Days × 10) + (Total XP × 0.1) + (Habits Attempted × 50)
     * Uses max streak across tracked habits as "current streak days" proxy for MVP.
     */
    fun leaderboardScore(
        habitsBeaten: Int,
        bestStreak: Int,
        totalXp: Int,
        habitsAttempted: Int,
    ): Long {
        val xpPart = (totalXp * 0.1).toLong()
        return habitsBeaten * 1000L + bestStreak * 10L + xpPart + habitsAttempted * 50L
    }
}
