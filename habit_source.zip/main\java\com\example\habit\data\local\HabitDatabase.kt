package com.example.habit.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.habit.data.local.dao.CheckInDao
import com.example.habit.data.local.dao.PendingAiHabitDao
import com.example.habit.data.local.dao.TrackedHabitDao
import com.example.habit.data.local.dao.UserProfileDao
import com.example.habit.data.local.entity.CheckInEntity
import com.example.habit.data.local.entity.PendingAiHabitEntity
import com.example.habit.data.local.entity.TrackedHabitEntity
import com.example.habit.data.local.entity.UserProfileEntity

@Database(
    entities = [
        TrackedHabitEntity::class,
        CheckInEntity::class,
        UserProfileEntity::class,
        PendingAiHabitEntity::class,
    ],
    version = 2,
    exportSchema = false,
)
abstract class HabitDatabase : RoomDatabase() {
    abstract fun trackedHabitDao(): TrackedHabitDao
    abstract fun checkInDao(): CheckInDao
    abstract fun userProfileDao(): UserProfileDao
    abstract fun pendingAiHabitDao(): PendingAiHabitDao

    companion object {
        @Volatile
        private var instance: HabitDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tracked_habits ADD COLUMN lastAiInsight TEXT")
                db.execSQL("ALTER TABLE tracked_habits ADD COLUMN lastAiScanEpochMs INTEGER")
            }
        }

        fun getInstance(context: Context): HabitDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    HabitDatabase::class.java,
                    "habit.db",
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
        }
    }
}
