package com.example.habit.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = Teal40,
    onPrimary = Color.White,
    primaryContainer = Teal90,
    onPrimaryContainer = Slate17,
    secondary = Slate60,
    onSecondary = Color.White,
    secondaryContainer = Slate87,
    onSecondaryContainer = Slate17,
    tertiary = Coral50,
    onTertiary = Color.White,
    tertiaryContainer = Coral80,
    onTertiaryContainer = Slate17,
    background = Slate96,
    onBackground = Slate17,
    surface = Color.White,
    onSurface = Slate17,
    surfaceVariant = Slate87.copy(alpha = 0.55f),
    onSurfaceVariant = Slate60,
    outline = Slate87,
    outlineVariant = Slate87.copy(alpha = 0.6f),
    error = Color(0xFFBA1A1A),
    onError = Color.White,
)

private val DarkColorScheme = darkColorScheme(
    primary = Teal80,
    onPrimary = Slate17,
    primaryContainer = Teal40,
    onPrimaryContainer = Teal90,
    secondary = Slate87,
    onSecondary = Slate17,
    secondaryContainer = Slate35,
    onSecondaryContainer = Slate87,
    tertiary = Coral80,
    onTertiary = Slate17,
    tertiaryContainer = Color(0xFF7A2E18),
    onTertiaryContainer = Coral80,
    background = Slate17,
    onBackground = Slate96,
    surface = Slate35,
    onSurface = Slate96,
    surfaceVariant = Slate60.copy(alpha = 0.35f),
    onSurfaceVariant = Slate87,
    outline = Slate60,
    outlineVariant = Slate60.copy(alpha = 0.45f),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
)

@Composable
fun HabitTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    /** Set false to use the Habit palette; dynamic color overrides brand on Android 12+. */
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = HabitShapes,
        content = content,
    )
}
