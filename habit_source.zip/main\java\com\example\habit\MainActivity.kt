package com.example.habit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.habit.ui.HabitApp
import com.example.habit.ui.theme.HabitTheme
import com.example.habit.ui.viewmodel.HabitViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as HabitApplication
        setContent {
            HabitTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val viewModel: HabitViewModel = viewModel(factory = HabitViewModel.factory(app.repository))
                    HabitApp(viewModel = viewModel)
                }
            }
        }
    }
}
