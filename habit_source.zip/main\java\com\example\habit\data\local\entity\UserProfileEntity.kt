package com.example.habit.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val onboardingComplete: Boolean,
    val totalXp: Int,
    val weeklyXp: Int,
    val weekStartEpochDay: Long,
    val habitsBeaten: Int,
    val firstAiScanDone: Boolean,
    val leaderboardVisibility: String,
    val moneySavedInr: Long,
)
