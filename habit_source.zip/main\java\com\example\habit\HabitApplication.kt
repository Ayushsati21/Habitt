package com.example.habit

import android.app.Application
import com.example.habit.BuildConfig
import com.example.habit.data.HabitRepository
import com.example.habit.data.local.HabitDatabase

class HabitApplication : Application() {
    lateinit var repository: HabitRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = HabitDatabase.getInstance(this)
        repository = HabitRepository(db, BuildConfig.CLAUDE_API_KEY)
    }
}
