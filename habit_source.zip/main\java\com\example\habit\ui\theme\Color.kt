package com.example.habit.ui.theme

import androidx.compose.ui.graphics.Color

// Brand — calm teal + deep slate (behaviour change / clarity, not “clinical cold”)
val Teal40 = Color(0xFF0D5C4C)
val Teal60 = Color(0xFF0F7665)
val Teal80 = Color(0xFF5EEAD4)
val Teal90 = Color(0xFFCCFBF1)

val Slate17 = Color(0xFF0F172A)
val Slate35 = Color(0xFF1E293B)
val Slate60 = Color(0xFF475569)
val Slate87 = Color(0xFFCBD5E1)
val Slate96 = Color(0xFFF1F5F9)

val Coral50 = Color(0xFFF9735A)
val Coral80 = Color(0xFFFFCBB5)

val Success = Color(0xFF16A34A)
val Warning = Color(0xFFD97706)
